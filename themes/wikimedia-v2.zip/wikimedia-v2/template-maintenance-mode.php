<?php get_header(); ?>

	<div class="main shell cf">
		<div class="content">
			<h1>The Wikimedia Blog is undergoing a planned upgrade.</h1>
			<p>Please check back shortly.</p>
		</div><!-- /.content -->

	</div><!-- /.main -->

<?php get_footer();